#include "fun.h"
#include<math.h>
fun::fun(QObject *parent) : QObject(parent)
{

}
double fun::jia(double x1,double x2)//加法
{
    double result=x1+x2;
    return result;
}
double fun::jian(double x1,double x2)//减法
{
    double result =x1-x2;
    return result;
}
double fun::cheng(double x1,double x2)//乘法
{
    double result=x1*x2;
    return result;
}
double fun::chu(double x1,double x2)//除法
{
    double result=x1/x2;
    return result;
}
double fun::Sin(double x)//求sin值
{
    double pi=3.14159;
    double result=sin(x);
}
