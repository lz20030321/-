#ifndef FRACTION_H
#define FRACTION_H

#include<QString>
class Fraction{
public:
    Fraction();
    ~Fraction();
    int a;
    int b;
    void print();
    //化简并设置分数
    void set(int a,int b);
    //分数减法
    Fraction subtract(Fraction f);
    //分数加法
    Fraction sum(Fraction f);
    //分数乘法
    Fraction multi(Fraction f);
    //分数除法
    Fraction division(Fraction f);
    QString toString();
};

#endif // FRACTION_H
