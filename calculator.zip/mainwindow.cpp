#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QDebug>
#include<QVector>
#include<math.h>
#include<string>
double pi=3.14159;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    init();
    on_actionnumber_triggered();
    ui->stackedWidget_2->setCurrentWidget(ui->inverse);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::init(){
   QVector<QLineEdit*>vector1;
   vector1.push_back(ui->num1);vector1.push_back(ui->num2);
   vector1.push_back(ui->num3);vector1.push_back(ui->num4);
   vector1.push_back(ui->num5);
    QVector<QLineEdit*>vector2;
   vector2.push_back(ui->num6);vector2.push_back(ui->num7);
   vector2.push_back(ui->num8);vector2.push_back(ui->num9);
   vector2.push_back(ui->num10);
   QVector<QLineEdit*>vector3;
   vector3.push_back(ui->num11);vector3.push_back(ui->num12);
   vector3.push_back(ui->num13);vector3.push_back(ui->num14);
   vector3.push_back(ui->num15);
   QVector<QLineEdit*>vector4;
   vector4.push_back(ui->num16);vector4.push_back(ui->num17);
   vector4.push_back(ui->num18);vector4.push_back(ui->num19);
   vector4.push_back(ui->num20);
   QVector<QLineEdit*>vector5;
   vector5.push_back(ui->num21);vector5.push_back(ui->num22);
   vector5.push_back(ui->num23);vector5.push_back(ui->num24);
   vector5.push_back(ui->num25);
   my_vector1.push_back(vector1);
   my_vector1.push_back(vector2);
   my_vector1.push_back(vector3);
   my_vector1.push_back(vector4);
   my_vector1.push_back(vector5);
   for(int i=0;i<5;i++){
       for(int j=0;j<5;j++){
           my_vector1[i][j]->setText(QString("0"));
       }
   }

   QVector<QLineEdit*>vector6;
   vector6.push_back(ui->num1_2);vector6.push_back(ui->num2_2);
   vector6.push_back(ui->num3_2);vector6.push_back(ui->num4_2);
   vector6.push_back(ui->num5_2);
    QVector<QLineEdit*>vector7;
   vector7.push_back(ui->num6_2);vector7.push_back(ui->num7_2);
   vector7.push_back(ui->num8_2);vector7.push_back(ui->num9_2);
   vector7.push_back(ui->num10_2);
   QVector<QLineEdit*>vector8;
   vector8.push_back(ui->num11_2);vector8.push_back(ui->num12_2);
   vector8.push_back(ui->num13_2);vector8.push_back(ui->num14_2);
   vector8.push_back(ui->num15_2);
   QVector<QLineEdit*>vector9;
   vector9.push_back(ui->num16_2);vector9.push_back(ui->num17_2);
   vector9.push_back(ui->num18_2);vector9.push_back(ui->num19_2);
   vector9.push_back(ui->num20_2);
   QVector<QLineEdit*>vector10;
   vector10.push_back(ui->num21_2);vector10.push_back(ui->num22_2);
   vector10.push_back(ui->num23_2);vector10.push_back(ui->num24_2);
   vector10.push_back(ui->num25_2);
   my_vector2.push_back(vector6);
   my_vector2.push_back(vector7);
   my_vector2.push_back(vector8);
   my_vector2.push_back(vector9);
   my_vector2.push_back(vector10);
   for(int i=0;i<5;i++){
       for(int j=0;j<5;j++){
           my_vector2[i][j]->setText(QString("0"));
       }
   }

   //设置结果选项
   ui->comboBox->addItem(QString("逆矩阵"));
   ui->comboBox->addItem(QString("相加结果"));
   ui->comboBox->addItem(QString("相减结果"));
   ui->comboBox->addItem(QString("相乘结果"));
}


void MainWindow::on_b1_clicked()
{
    ui->lineEdit->insert("1");
}

void MainWindow::on_pushButton_5_clicked()
{
    ui->lineEdit->insert("2");
}

void MainWindow::on_pushButton_9_clicked()
{
    ui->lineEdit->insert("3");
}

void MainWindow::on_pushButton_clicked()
{
    ui->lineEdit->insert("4");
}

void MainWindow::on_pushButton_6_clicked()
{
    ui->lineEdit->insert("5");
}

void MainWindow::on_pushButton_10_clicked()
{
    ui->lineEdit->insert("6");
}

void MainWindow::on_pushButton_3_clicked()
{
    ui->lineEdit->insert("7");
}

void MainWindow::on_pushButton_7_clicked()
{
    ui->lineEdit->insert("8");
}

void MainWindow::on_pushButton_11_clicked()
{
    ui->lineEdit->insert("9");
}

void MainWindow::on_pushButton_4_clicked()
{
    ui->lineEdit->insert(".");
}

void MainWindow::on_pushButton_8_clicked()
{
    ui->lineEdit->insert("0");
}

void MainWindow::on_pushButton_13_clicked()
{
    ui->lineEdit->insert("+");
}

void MainWindow::on_pushButton_14_clicked()
{
    ui->lineEdit->insert("-");
}

void MainWindow::on_pushButton_15_clicked()
{
    ui->lineEdit->insert("*");
}

void MainWindow::on_pushButton_16_clicked()
{
    ui->lineEdit->insert("/");
}

void MainWindow::on_pushButton_12_clicked()
{
    QString m;//储存已输入的信息
    m=ui->lineEdit->text();
    if(m.isEmpty())//若为空白情况
    {
      return;
    }
    if(m.indexOf("+")!=-1)//加法
    {
        double i=m.indexOf("+");
        double x1=m.leftRef(i).toDouble();
        double x2=m.rightRef(m.size()-i).toDouble();
        double k=f.jia(x1,x2);
        ui->lineEdit->setText(QString::number(k));
    }
    if(m.indexOf("-")!=-1)//减法
    {
        double i=m.indexOf("-");
        double x1=m.leftRef(i).toDouble();
        double x2=m.rightRef(m.size()-i).toDouble();
        double k=f.jian(x1,x2);
        ui->lineEdit->setText(QString::number(k));
    }
    if(m.indexOf("*")!=-1)//乘法
    {
        double i=m.indexOf("*");
         qDebug()<<i;
        double x1=m.leftRef(i).toDouble();
        double x2=m.rightRef(m.size()-i-1).toDouble();
        qDebug()<<x1<<x2;
        double k=f.cheng(x1,x2);
        ui->lineEdit->setText(QString::number(k));
    }
    if(m.indexOf("/")!=-1)//除法
    {
        double i=m.indexOf("/");
        double x1=m.leftRef(i).toDouble();
        double x2=m.rightRef(m.size()-i-1).toDouble();
        double k=f.chu(x1,x2);
        ui->lineEdit->setText(QString::number(k));
    }
    if(m.indexOf("√")!=-1)//开根号
    {
        double x=m.rightRef(m.size()-1).toDouble();
        double k=sqrt(x);
        ui->lineEdit->setText(QString::number(k));
    }
    if(m.indexOf("sin")!=-1)//求sin
    {

      double x=m.rightRef(m.size()-3).toDouble();
      double k=sin(x);
      ui->lineEdit->setText(QString::number(k));
    }
    if(m.indexOf("cos")!=-1)//求cos
    {
        double x=m.rightRef(m.size()-3).toDouble();
        double k=cos(x);
        ui->lineEdit->setText(QString::number(k));
    }
    if(m.indexOf("tan")!=-1)//求tan
    {
        double x=m.rightRef(m.size()-3).toDouble();
        double k=tan(x);
        ui->lineEdit->setText(QString::number(k));
    }
}
void MainWindow::matrix_cal(){
   ui->textEdit_2->clear();
   ui->textEdit_3->clear();
   ui->textEdit_4->clear();
   matrix temp1=m_matrix1;
   matrix temp2=m_matrix2;
   temp1.n=rank;temp2.n=rank;
   //相加的结果
   matrix result1=temp1.sum(temp2);
   result1.n=rank;
   ui->textEdit_2->insertPlainText(result1.toString());
   //相减的结果
   matrix result2=temp1.subtract(temp2);
   result2.n=rank;
   ui->textEdit_3->insertPlainText(result2.toString());
   //相乘的结果
   matrix result3=temp1.multi(temp2);
   result3.n=rank;
   ui->textEdit_4->insertPlainText(result3.toString());
}

void MainWindow::matrix_inverse(){
    ui->textEdit->clear();
    //利用初等行变换求逆矩阵
    matrix temp=m_matrix1;
    temp.n=rank;
    matrix result;
    result.n=rank;
    //逆矩阵初始化，对角线置为1
    for(int i=0;i<rank;i++){
        result.fraction[i][i].a=1;
    }
    //把每一行对角线左边的数变为0
    for(int i=0;i<rank;i++){
        for(int j=0;j<i;j++){
            Fraction f1=temp.fraction[i][j];
            if(f1.a!=0){
                for(int k=0;k<rank;k++){
                    temp.fraction[i][k]=temp.fraction[i][k].subtract(f1.multi(temp.fraction[j][k]));
                    result.fraction[i][k]=result.fraction[i][k].subtract(f1.multi(result.fraction[j][k]));
                }
            }
        }
       //把每一行对角线变为1
         Fraction f2=temp.fraction[i][i];
         if(f2.a==0)
             return;
         else{
        for(int k=rank;k>=0;k--){
            temp.fraction[i][k]=temp.fraction[i][k].division(f2);
            result.fraction[i][k]=result.fraction[i][k].division(f2);
         }
         }

     }
    //每一行对角线右边的数变为0
    for(int i=0;i<rank;i++){
        for(int j=i+1;j<rank;j++){
            Fraction f3=temp.fraction[i][j];
            if(f3.a!=0){
                for(int k=0;k<rank;k++){
                    temp.fraction[i][k]=temp.fraction[i][k].subtract(f3.multi(temp.fraction[j][k]));
                    result.fraction[i][k]=result.fraction[i][k].subtract(f3.multi(result.fraction[j][k]));
                }
            }
        }
    }
    ui->textEdit->insertPlainText(result.toString());
}

//设置为基本计算器的页面
void MainWindow::on_actionnumber_triggered()
{
    ui->stackedWidget->setCurrentWidget(ui->page);
    this->resize(420,560);
}
//设置为矩阵计算器的页面
void MainWindow::on_actionmatrix_triggered()
{
    ui->stackedWidget->setCurrentWidget(ui->page_2);
    this->resize(979,673);
}
//改变矩阵阶数
void MainWindow::on_spinBox_valueChanged(int arg1)
{
    rank=arg1;
   if(arg1>=5){
       ui->spinBox->setValue(5);
       rank=5;
   }
   else if(arg1<=1){
        ui->spinBox->setValue(1);
        rank=1;
   }
}
//重置矩阵
void MainWindow::on_clear1_clicked()
{
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            my_vector1[i][j]->setText(QString("0"));
        }
    }
}

void MainWindow::on_clear2_clicked()
{
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            my_vector2[i][j]->setText(QString("0"));
        }
    }
}

void MainWindow::on_sure1_clicked()
{
    //读取矩阵1输入的数值
    m_matrix1.n=rank;
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            m_matrix1.fraction[i][j].a=my_vector1[i][j]->text().toInt();
            m_matrix1.fraction[i][j].b=1;
        }
    }
    matrix_inverse();
}

void MainWindow::on_sure2_clicked()
{ //读取矩阵2输入的数值
    m_matrix2.n=rank;
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            m_matrix2.fraction[i][j].a=my_vector2[i][j]->text().toInt();
            m_matrix2.fraction[i][j].b=1;
        }
    }
    matrix_cal();
}

void MainWindow::on_comboBox_currentTextChanged(const QString &arg1)
{
    if(arg1=="逆矩阵"){
        ui->stackedWidget_2->setCurrentWidget(ui->inverse);
    }
    if(arg1=="相加结果"){
       ui->stackedWidget_2->setCurrentWidget(ui->sum);
    }
    if(arg1=="相减结果"){
       ui->stackedWidget_2->setCurrentWidget(ui->subtract);
    }
    if(arg1=="相乘结果"){
       ui->stackedWidget_2->setCurrentWidget(ui->multi);
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    ui->lineEdit->insert("π");
}

void MainWindow::on_pushButton_17_clicked()
{
    ui->lineEdit->insert("sin");
}

void MainWindow::on_pushButton_20_clicked()
{
    ui->lineEdit->insert("cos");
}

void MainWindow::on_pushButton_21_clicked()
{
    ui->lineEdit->insert("tan");
}

void MainWindow::on_pushButton_22_clicked()
{
    ui->lineEdit->insert("√");
}

void MainWindow::on_pushButton_24_clicked()
{
    ui->lineEdit->clear();
}

void MainWindow::on_pushButton_23_clicked()
{

    ui->lineEdit->backspace();
}


