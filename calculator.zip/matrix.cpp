#include "matrix.h"

matrix::matrix()
{
    n=5;
    fraction=new Fraction*[5];
    for(int i=0;i<5;i++){
        fraction[i]=new Fraction[5];
    }
}
matrix::matrix(const matrix& m){
    this->n=m.n;
    fraction=new Fraction*[5];
    for(int i=0;i<5;i++){
        fraction[i]=new Fraction[5];
    }
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            fraction[i][j]=m.fraction[i][j];
        }
    }
}
 matrix::~matrix(){
     for(int i=0;i<5;i++){
         delete []fraction[i];
     }
     delete []fraction;
 }

Fraction matrix::multify(matrix m,int row,int col){
    Fraction temp;
    for(int i=0;i<n;i++){
       temp=temp.sum(fraction[row][i].multi(m.fraction[i][col]));
    }
    return temp;
}

matrix matrix::multi(matrix m){
   matrix temp;
   for(int i=0;i<n;i++){
       for(int j=0;j<n;j++){
           temp.fraction[i][j]=multify(m,i,j);
       }
   }
   return temp;
}
matrix matrix::sum(matrix m){
    matrix temp;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            temp.fraction[i][j]=this->fraction[i][j].sum(m.fraction[i][j]);
        }
    }
    return temp;
}

matrix matrix::subtract(matrix m){
    matrix temp;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            temp.fraction[i][j]=this->fraction[i][j].subtract(m.fraction[i][j]);
        }
    }
    return temp;
}
 QString matrix::toString(){
     QString string;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
              string+=fraction[i][j].toString();
            if(j==n-1){
                string+="\n\n";
            }
            else{
                string+="  ";
            }
        }
    }
    return string;
 }
