#ifndef MATRIX_H
#define MATRIX_H

#include"fraction.h"
#include<QString>
class matrix
{
public:
    matrix();
    matrix(const matrix&m);
     ~matrix();
    //矩阵阶数
    int n;
    //二维数组保存数据
    Fraction **fraction;
    //矩阵乘法
    Fraction multify(matrix m,int row,int col);
    matrix multi(matrix m);
    //矩阵加法
    matrix sum(matrix m);
    //矩阵减法
    matrix subtract(matrix m);
    QString toString();
};


#endif // MATRIX_H
