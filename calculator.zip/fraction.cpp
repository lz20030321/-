#include "fraction.h"

Fraction::Fraction(){
    //初始化分子为0，分母为1
    a=0;
    b=1;
}
void Fraction::print(){
    //qDebug()<<toString();
}
void Fraction::set(int a, int b){
    //检查是否是最简分数
    if(b<0)
    {
        b=-b;
        a=-a;
    }
    bool check=false;
    if(a!=0){
     if(a<0)
     {
         check=true;
         a=-a;
     }
    int i=2;
    while(i<=(a<=b?a:b)){
        if(a%i==0&&b%i==0){
            a/=i;
            b/=i;
        }
        else{
            i++;
        }
    }
    }
    //设置分子分母
    if(check){
        a=-a;
    }
    this->a=a;
    this->b=b;
}
Fraction Fraction::subtract(Fraction f){
     Fraction temp;
     int a=this->a*f.b-this->b*f.a;
     int b=this->b*f.b;
     temp.set(a,b);
     return temp;
}
Fraction Fraction::sum(Fraction f){
     Fraction temp;
     int a=this->a*f.b+this->b*f.a;
     int b=this->b*f.b;
     temp.set(a,b);
     return temp;
}
Fraction Fraction::multi(Fraction f){
     Fraction temp;
     int a=this->a*f.a;
     int b=f.b*this->b;
     temp.set(a,b);
     return temp;
}
Fraction Fraction::division(Fraction f){
     Fraction temp;
     int a=this->a*f.b;
     int b=f.a*this->b;
     temp.set(a,b);
     return temp;
}
QString Fraction::toString(){
    if(a==0||b==1){
        return QString::number(a);
    }
    return QString::number(a)+"/"+QString::number(b);
}
Fraction::~Fraction(){

}
