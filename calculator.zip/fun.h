#ifndef FUN_H
#define FUN_H

#include <QObject>

class fun : public QObject
{
    Q_OBJECT
public:
    explicit fun(QObject *parent = nullptr);
    double jia(double x1,double x2);//加法
    double jian(double x1,double x2);//减法
    double cheng(double x1,double x2);//乘法
    double chu(double x1,double x2);//除法
    double Sin(double x);//求sin值
    double Cos(double x);//求cos值
signals:

};

#endif // FUN_H
