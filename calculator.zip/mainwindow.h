#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QLineEdit>
#include"fun.h"
#include"matrix.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
     fun f;
     //矩阵阶数
     int rank;
     //便于获取输入的矩阵的值
     QVector<QVector<QLineEdit*>>my_vector1;
     QVector<QVector<QLineEdit*>>my_vector2;
     //矩阵1
     matrix m_matrix1;
     //矩阵2
     matrix m_matrix2;
     //初始化
     void init();
     //加，减，乘
     void matrix_cal();
     //矩阵1求逆
     void matrix_inverse();
private slots:
     void on_b1_clicked();

     void on_pushButton_5_clicked();

     void on_pushButton_9_clicked();

     void on_pushButton_clicked();

     void on_pushButton_6_clicked();

     void on_pushButton_10_clicked();

     void on_pushButton_3_clicked();

     void on_pushButton_7_clicked();

     void on_pushButton_11_clicked();

     void on_pushButton_4_clicked();

     void on_pushButton_8_clicked();

     void on_pushButton_13_clicked();

     void on_pushButton_14_clicked();

     void on_pushButton_15_clicked();

     void on_pushButton_16_clicked();

     void on_pushButton_12_clicked();
    //切换为基本计算器窗口
     void on_actionnumber_triggered();
    //切换为矩阵计算器窗口
     void on_actionmatrix_triggered();
    //选择阶数
     void on_spinBox_valueChanged(int arg1);
     //重置矩阵一
     void on_clear1_clicked();
    //重置矩阵二
     void on_clear2_clicked();
     //点击确定开始求逆
     void on_sure1_clicked();
     //点击确定开始加减乘
     void on_sure2_clicked();
    //下拉框选择想要查看的按钮
     void on_comboBox_currentTextChanged(const QString &arg1);

     void on_pushButton_2_clicked();

     void on_pushButton_17_clicked();

     void on_pushButton_20_clicked();

     void on_pushButton_21_clicked();

     void on_pushButton_22_clicked();

     void on_pushButton_24_clicked();

     void on_pushButton_23_clicked();

     void on_pushButton_12_windowIconTextChanged(const QString &iconText);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
